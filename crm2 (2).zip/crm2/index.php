<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="assets/css/index.css">
    <link rel="stylesheet" href="./bootstrap-5.1.3-dist/css/bootstrap.min.css" />

    <script src="./bootstrap-5.1.3-dist/js/bootstrap.min.js"></script>
    <title>CRM</title>
  </head>
  <body>
    <div class="main">
      <div class="leftmain">
        <div class="portfolio">
          <h3 class="text-center text-primary">Portfolio</h3>

        </div>
        <h5 class="text-center">Videos</h5>
        <div class=" videos">
          <div class="row">
            <div class="col-md-4">
              <div class="card">
                <video src=""></video>
              </div>
            </div>
            <div class="col-md-4">
            <div class="card"></div>
            </div>
            <div class="col-md-4">
            <div class="card"></div>
            </div>
          </div>
        </div>
        <p class="my-4 text-center text-light">Follow for more, Please click on <span class="text-danger"><strong>"Our Videos"</strong></span></p>
        <h2 class="text-center text-light">Follow Us On</h2>
        <div class="social">
          <img src="./assets/img/yt.jpg" alt="">
          <img src="./assets/img/fb.jpg" alt="">
          <img src="./assets/img/tweet.jpg" alt="">
          <img src="./assets/img/linkedin.jpg" alt="">
        </div>
        <h5 class="text-center text-danger my-4">kbnsoftwarepvt@gmail.com</h5>
      </div>
      <div class="rightmain">
        <div class="logo"><img src="./assets/img/logo.jpg" alt=""></div>
        <div class="login-box">
          <form action="" method="POST" class="login-form" >
            <h3 class="text-center " >Sign In</h3>
            <input type="text" placeholder="Enter username"><br>
            <input type="text" placeholder="Enter upassword">
            <p><a href="hello" id="forgot">Forgot password ?</a></p>
            <button class="submit-btn text-light shadow-lg" type="submit"><a href="/crm2/pages/dashboard.php"> Sign In</a></button>
          </form>
        </div>
      </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  </body>
</html>