<?php include '../assets/partials/_headers.php'; ?>
<?php include '../assets/partials/_dbconnect.php'; ?>
<?php include '../assets/partials/_fetchQueries.php'; ?>


<section class="section">
   <div class="sector2 shadow-sm">
  <div class="head1">
      <p>Manage accounts</p>
      <a href="./createnewaccount.php?status=new"><p class="btn btn-primary">create new account</p></a>
  </div>
<hr>
<form action="/crm2/pages/manageacc.php" method="POST" class="filter-form">
    <div class="row">
        <div class="col-md-3">  
            <div class="mb-3 form-input">
                <label for="exampleInputEmail1" class="form-label">Search</label>
                <input type="text" class="form-control" name="search" id="exampleInputEmail1" aria-describedby="emailHelp">
            </div>
        </div>
        <div class="col-md-3">  
            <div class="mb-3 form-input">
                <label for="exampleInputEmail1" class="form-label">From date</label>
                <input type="Date" class="form-control" name="fdate" id="exampleInputEmail1" aria-describedby="emailHelp">
            </div>
        </div>
        <div class="col-md-3">  
            <div class="mb-3 form-input">
                <label for="exampleInputEmail1" class="form-label">To Date</label>
                <input type="Date" class="form-control" name="tdate" id="exampleInputEmail1" aria-describedby="emailHelp">
            </div>
        </div>
       
        
    </div>
    <div class="col-md-3">  
            <div class="mb-3 btns py-4">
                <button class="btn btn-success mx-2" type="submit">Apply Filter</button>
                <button class="btn btn-danger" type="reset">Cancel</button>
            </div>
        </div>
</form>

<p class="mx-2">show  <input type="number" name="entries" id="entries"> entries</p>

<div class="table-main py-4 px-4">
<table class="table">
  <thead>
    <tr>
      <th scope="col">Account name</th>
      <th scope="col">Potentials</th>
      <th scope="col">Account type</th>
      <th scope="col">Account size</th>
      <th scope="col">Contact Info</th>
      <th scope="col">Address Info</th>
      <th scope="col">Business Type</th>
      <th scope="col">Actions</th>
    </tr>
  </thead>
  <tbody>
    <?php
    $result = getCustomerData($conn);

    

    while ($row = mysqli_fetch_assoc($result)) {
      $acname = $row['accname'];
    echo '
    <tr>
      <th scope="row">'.$row['accname'].'</th>
      <td><a href="./createnewaccount.php?status=show&&id='.$row['custId'].'">'; 
      if ($_SERVER['REQUEST_METHOD'] == "POST") {
        $search = $_POST['search'];
        $fdate = $_POST['fdate'];
        $tdate = $_POST['tdate'];
        $potentials = getFilterPotential($conn, $search,$fdate,$tdate);
        echo $potentials;
      }
      else{
        $potentials = "select COUNT(*) as number from potentials where `accname` = '$acname' ";
      }

      $presult = mysqli_query($conn, $potentials);
       while($row2 = mysqli_fetch_assoc($presult)){
         echo $row2['number'];
       }
    
      echo '</a></td>
      <td>'.$row['natureOfBusiness'].'</td>
      <td>'.$row['accsize'].'</td>
      <td>'.$row['contact'].'</td>
      <td>'.$row['address'].'</td>
      <td>'.$row['btype'].'</td>
        <td> <a href="./createnewaccount.php?status=edit&id='.$row['custId'].'"> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" style="color:red;" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
  <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
  <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/>
</svg></td>
    </tr>';
  }
    ?>
  </tbody>
</table>
</div>

   </div>

</div>



</section>

<footer class="foot">
<h5>2022 @ KBN CRM</h5>
<h5>kbnsoftwarepvt@gmail.com</h5>
</footer>


<script>

$(".navigation li").hover(function() {
  var isHovered = $(this).is(":hover");
  if (isHovered) {
    $(this).children("ul").stop().slideDown(300);
  } else {
    $(this).children("ul").stop().slideUp(300);
  }
});


</script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  </body>
</html>