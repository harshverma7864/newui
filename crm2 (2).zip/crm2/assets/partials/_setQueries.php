<?php 

include '_dbconnect.php';

$table = $_GET['t'];

// if ($table == 'p') {
//     $mksource = $_POST['mksource'];
//     $saccname = $_POST['saccname'];
//     $contperson = $_POST['contperson'];
//     $rank = $_POST['rank'];
//     $potname = $_POST['potname'];
//     $estdealvalue = $_POST['estdealvalue'];
//     $exclosuredate = $_POST['exclosuredate'];
//     $parentcat = $_POST['parentcat'];
//     $product = $_POST['product'];
//     $nsdd = $_POST['nsdd'];
//     $NOT = $_POST['NOT'];
//     $bvertical = $_POST['bvertical'];
//     $region = $_POST['region'];
//     $state = $_POST['state'];
//     $city = $_POST['city'];
//     $requirements = $_POST['requirements'];

   
//     $sql = "Insert into potentials (`mksource`, `accname`, `contperson`, `rank`, `potname`,`estdealvalue`,`exclosuredate`,`parentcat`,`product`,`nsdd`,`NOT`,`region`,`state`,`city`,`requirements`) VALUES 
//                                    ('$mksource', '$accname', '$contperson', '$rank', '$potname','$estdealvalue','$exclosuredate','$parentcat','$product','$nsdd','$NOT','$region','$state','$city','$requirements')";
//     $result = mysqli_query($conn,$sql);
    
//     if ($result) {
//         $alert = "Potential added successfully";
//         header("location: /crm2/pages/createnwepotentials.php?alert=$alert");
//     }
        
         
     

// }
if ($table == 'e') {
    $empname = $_POST['empName'];
    $empemail = $_POST['empEmail'];
    $empContact = $_POST['empContact'];
    $empdesignation = $_POST['empd'];
    $emppassword = $_POST['password'];
    $empcpassword = $_POST['cpassword'];
    $role = $_POST['role'];
    $select = "select email from employee where email = '$empemail'";
    $em = mysqli_query($conn, $select);
    $num = mysqli_num_rows($em);
    if ( $num == 0) {
        if ($emppassword == $empcpassword) {
            $sql = "Insert into employee (`email`, `name`, `password`, `designation`, `contact`) VALUES ('$empemail', '$empname','$emppassword','$empdesignation', '$empContact')";
            $result = mysqli_query($conn,$sql);
            $em = "select empId from employee where email = '$empemail'";
            $empresult = mysqli_query($conn,$em);
            $row = mysqli_fetch_assoc($empresult);
            $empid = $row['empId'];
            $sql2 = "Insert into users (`username`,`email`,`password`,`role`,`empId`) VALUES ('$empname', '$empemail', '$emppassword','$role','$eid')";
            $result2 = mysqli_query($conn,$sql2);
            if ($result) {
                $alert = "Employee Added successfully !!!!";
                header("location: /crm/dashboard.php?alert=$alert");
            }
        }
        else{
            $alert = "Password and confirm password must be same !!!!";
            header("location: /crm/dashboard.php?alert=$alert");
        }
    }
    else{
        $alert = "Employee with this email already exist";
        header("location: /crm/dashboard.php?alert=$alert");
    }

}

if ($table == 'p') {
    
    
  
   
    $status = $_POST['status'];
    $mksource = $_POST['mksource'];
    $accname = $_POST['saccname'];
    $contperson = $_POST['contperson'];
    $rank = $_POST['rank'];
    $potname = $_POST['potname'];
    $estdealvalue = $_POST['estdealvalue'];
    $exclosuredate = $_POST['exclosuredate'];
    $parentcat = $_POST['parentcat'];
    $product = $_POST['product'];
    $nsdd = $_POST['nsdd'];
    $NOT = $_POST['NOT'];
    $bvertical = $_POST['bvertical'];
    $region = $_POST['region'];
    // $state = $_POST['state'];
    // $city = $_POST['city'];
    $requirements = $_POST['requirements'];
    
    if ($status == 'new') {
     
   
    
    $insert = "insert into potentials (`mksource`,`accname`,`contperson`,`rank`,`potname`,`estdealvalue`,`exclosuredate`,`parentcat`,`product`,`nsdd`,`NOT`,`bvertical`,`region`,`state`,`city`,`requirements`) values 
                                      ('$mksource','$accname','$contperson','$rank','$potname','$estdealvalue','$exclosuredate','$parentcat','$product','$nsdd','$NOT','$bvertical','$region','$state','$city','$requirements')";

    $result = mysqli_query($conn,$insert);
    if($result){
        $alert = "Potential added";
        header("location: /crm2/pages/createnwepotentials.php?status=new&alert=$alert");
    }
    else{
        $alert = "Error adding Potential ";
        header("location: /crm2/pages/createnwepotentials.php?status=new&alert=$alert");
    }
}else{
    $id = $_POST['id'];
    $update = "UPDATE `potentials` SET `mksource` = 'ISSd', `accname` = 'ssadssd', `contperson` = '2sd', `rank` = 'Warmd', `potname` = 'asdas', `estdealvalue` = 'asddasssa', `exclosuredate` = '2022-05-da18', `parentcat` = 'uBook360sd', `product` = '1sa', `nsdd` = 'asdsadassad', `NOT` = '0 - 20000asd', `bvertical` = 'Rubberasd', `region` = 'Eastad', `state` = 'DLad', `city` = 'HRad', `requirements` = 'sadsaassadasd' WHERE `potentials`.`appid` = '$id'";
    $result = mysqli_query($conn,$update);
    if ($result) {
        $alert = "Potential updated";
        header("location: /crm2/pages/createnwepotentials.php?status=edit&alert=$alert&id=$id");
    }
}
}

if ($table == 'c') {    
    $status = $_POST['status']; 
    $email = $_POST['csemail'];
    $name = $_POST['csname'];
    $Contact = $_POST['csnumber'];
    $designation = $_POST['cdesignation'];
    $address = $_POST['addinfo'];
    $zip = $_POST['pincode'];
    // $country = $_POST['country'];
    $district = $_POST['city'];
    $accname = $_POST['accname'];
    // echo "ans id".$accname;
   
    $state = $_POST['state'];
    $acctype = $_POST['acctype'];
    $accsize = $_POST['accsize'];
    $bln = $_POST['bln'];
    $bweb = $_POST['bweb'];
    $btype = $_POST['btype'];
    $empsize = $_POST['empsize'];
    $annrev = $_POST['annrev'];
    $ctype = $_POST['ctype'];

    if ( $status == "new") {
    
    $sql4 = "select * from customer where email = '$email'";
    $result4 = mysqli_query($conn,$sql4);
    $row = mysqli_fetch_assoc($result4);
    if ($row == NULL){
        
        $sql = "Insert into customer (`email`, `name`, `contact`, `designation`, `address`, `district`, `state`, `zipCode`, `natureOfBusiness`, `accname`, `accsize`,`bln`,`bweb`, `btype`,`empsize`,`annrev`,`ctype`) VALUES 
                                     ('$email', '$name','$Contact','$designation', '$address', '$district', '$state', '$zip', '$acctype','$accname','$accsize','$bln', '$bweb', 'btype', '$empsize' , '$annrev', '$ctype' )";
        $result = mysqli_query($conn,$sql);
        if ($result) {
            $alert = "Customer Added successfully !!!!";
            header("location: /crm2/pages/createnewaccount.php?status=new&alert=$alert");
        }
        else{
            $alert = "There is some problem !!!!";
            header("location:  /crm2/pages/createnewaccount.php?status=new&alert=$alert");
        }  
    }
    else{

        $alert = "Customer Already Exist !!!!";
        header("location:  /crm2/pages/createnewaccount.php?status=new&alert=$alert");
    }
}
else {
    $id = $_POST['id'];
    $update = "UPDATE `customer` SET `email` = '$email', `name` = '$name', 
    `contact` = '$contact', `designation` = '$designation', `address` = '$address', 
    `district` = '$district', `state` = '$state', `zipCode` = ' $zip', `natureOfBusiness` = '$acctype', 
    `accname` = '$accname', `accsize` = '$accsize', `bln` = '$bln', `bweb` = '$bweb', 
    `btype` = '$btype', `empsize` = '$empsize', `annrev` = '$annrev', `ctype` = '$ctype' WHERE `custId` = '$id'";

    $result = mysqli_query($conn,$update);
    if ($result) {
        $alert = "Customer updated successfully !!!!";
        header("location: /crm2/pages/createnewaccount.php?status=edit&alert=$alert&&id=$id");
    }
    else{
        $alert = "Error updating data !!!!";
        header("location: /crm2/pages/createnewaccount.php?status=new&alert=$alert&&id=$id");
    }
}
}



if ($table == 'ed') {
    $cname = $_POST['companyName'];
    $appid = $_POST['appNumber'];
    $vdate = $_POST['visitdate'];
    $nfd = $_POST['nfd'];
    $empid = $_POST['empass'];
    $remarks = $_POST['remarks'];
    $status = $_POST['status'];
    if ($vdate == NULL) {
        $sql = "Update crmappointmentm set remarks = '$remarks' , nextFollowUpDate = '$nfd' , empId = '$empid',status = '$status' where appId = '$appid'";

    }
    else if ($empid == NULL) 
    {
        $sql = "Update crmappointmentm set visitDate = '$vdate', remarks = '$remarks' , nextFollowUpDate = '$nfd' ,status = '$status' where appId = '$appid'";

    }
    else{
        $sql = "Update crmappointmentm set  visitDate = '$vdate',  remarks = '$remarks' , nextFollowUpDate = '$nfd', empId = '$empid' ,status = '$status' where appId = '$appid'";

    }
    $result = mysqli_query($conn,$sql);
    if ($result) {
        $alert = "Appointment Edited successfuly !!!!";
        header("location: /crm/dashboard.php?alert=$alert");
    }
    else{
        $alert = "There is some problem !!!!";
        header("location: /crm/dashboard.php?alert=$alert");
    }
}



?>