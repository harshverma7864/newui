<?php 

include './_dbconnect.php';

$toDate = $_POST['tdate']
$fDate = $_POST['fdate']
$search = $_POST['search']

$sql = "select * from potentials "

if ($tdate!= "" && $fdate != "") {
    $sql =  $sql."where nsdd >= '$fDate' and nsdd <= '$toDate'";
}

else if ($toDate != "" && $fDate == ""){
    $sql =  $sql."where nsdd <= '$toDate'"; 
}

else if($toDate == "" && $fDate != ""){
    $sql =  $sql."where nsdd >= '$fDate'"; 
}


?>